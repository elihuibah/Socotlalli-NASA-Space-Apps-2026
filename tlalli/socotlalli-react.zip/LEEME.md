# Socotlalli · prototipo de interfaz (React + Vite + TypeScript)

## Integrarlo al repositorio del equipo
1. Copien la carpeta `src/` completa sobre la de su proyecto (reemplaza `App.tsx`, `main.tsx` e `index.css` de la plantilla; borren `App.css` e `index.css` si quedan).
2. Copien también `index.html` (título, idioma español y meta de viewport).
3. Instalen la fuente: `npm install @fontsource-variable/urbanist`
4. `npm run dev`

## Qué reemplaza cada equipo
- **Datos:** `src/data/discs.ts` → cambiar `mockFrames(...)` por los valores de cada `disc.json` y llenar `image` con la ruta del fotograma.
- **Audio:** `src/audio/engine.ts` → reemplazar la implementación por Tone.js manteniendo la interfaz `AudioEngine` (es el contrato 2 del plan).
- **Arte:** `src/components/Tlalli.tsx` → cambiar `.tlalli-ph` por la ilustración; las portadas se dibujan en CSS en `src/styles/app.css` (`.cover--ocean`, etc.).
- **Colores:** `src/styles/tokens.css` → sustituir los valores aproximados por los exactos de Coolors.

`npm run build:single` (con `vite-plugin-singlefile` instalado) genera un solo HTML para compartir la demo.
