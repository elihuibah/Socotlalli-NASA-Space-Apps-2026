// Datos de EJEMPLO. El equipo de Datos reemplaza `frames` con los valores reales de cada disc.json.
// Todos los textos entre corchetes son marcadores que se sustituyen con datos reales.

export type CoverStyle = 'ocean' | 'ice' | 'leaves' | 'air' | 'currents';

export interface Frame {
  label: string; // "[AÑO 1] · [MES 1]" → en real: "Marzo de 2024"
  year: number; // índice del año dentro del periodo
  text: string; // descripción en lenguaje llano del fotograma
  image?: string; // ruta al fotograma del EIC (frames/sst/012.jpg)
  value: number; // 0 a 1: valor medio de la zona
  anomaly: number; // -1 a 1: distancia a lo normal
  variation: number; // 0 a 1: variación entre píxeles vecinos
  change: number; // 0 a 1: cambio respecto al fotograma anterior
}

export interface Disc {
  id: string;
  opus: number;
  title: string;
  short: string;
  variable: string;
  units: string;
  instrument: string;
  wave: OscillatorType; // timbre del sintetizador provisional
  baseMidi: number;
  howItSounds: string;
  source: string;
  cover: CoverStyle;
  ready: boolean;
  frames: Frame[];
}

export interface Region {
  id: string;
  name: string;
  col: number; // rejilla de 32 x 16 celdas
  row: number;
  w: number;
  h: number;
}

export const FRAME_MS = 4500;
export const FRAMES_PER_YEAR = 3;
export const YEARS = ['[AÑO 1]', '[AÑO 2]', '[AÑO 3]', '[AÑO 4]'];
export const GRID = { cols: 32, rows: 16 };

export const REGIONS: Region[] = [
  { id: 'baja', name: 'Pacífico frente a Baja California', col: 4, row: 4, w: 3, h: 3 },
  { id: 'golfo', name: 'Golfo de México', col: 7, row: 5, w: 2, h: 2 },
  { id: 'atlantico', name: 'Atlántico norte', col: 11, row: 3, w: 4, h: 3 },
  { id: 'artico', name: 'Ártico', col: 10, row: 0, w: 12, h: 2 },
  { id: 'indico', name: 'Océano Índico', col: 21, row: 8, w: 4, h: 3 },
  { id: 'global', name: 'Todo el planeta', col: 0, row: 0, w: 32, h: 16 },
];

function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

const clamp = (n: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, n));

function mockFrames(seed: number, trend: number, units: string): Frame[] {
  const r = seeded(seed);
  const total = YEARS.length * FRAMES_PER_YEAR;
  return Array.from({ length: total }, (_, i) => {
    const t = i / (total - 1);
    const year = Math.floor(i / FRAMES_PER_YEAR);
    return {
      label: `${YEARS[year]} · [MES ${(i % FRAMES_PER_YEAR) + 1}]`,
      year,
      text: `[Fotograma ${i + 1}: zona, valor en ${units} y si está sobre o bajo lo normal]`,
      value: clamp(0.3 + t * 0.45 * trend + (r() - 0.5) * 0.2),
      anomaly: clamp(t * 1.6 * trend - 0.5 * trend + (r() - 0.5) * 0.35, -1, 1),
      variation: 0.2 + r() * 0.6,
      change: i === 0 ? 0.2 : 0.15 + r() * 0.5,
    };
  });
}

export const DISCS: Disc[] = [
  {
    id: 'sst',
    opus: 1,
    title: 'Fiebre del océano',
    short: 'Op. 1, Fiebre del océano',
    variable: 'Temperatura de la superficie del mar',
    units: '°C',
    instrument: 'Piano',
    wave: 'triangle',
    baseMidi: 57,
    howItSounds: 'Más cálido, más agudo y brillante. Cuando el mar se aleja de lo normal, la armonía se tensa.',
    source: '[Título de la visualización del EIC]',
    cover: 'ocean',
    ready: true,
    frames: mockFrames(11, 1, '°C'),
  },
  {
    id: 'ice',
    opus: 2,
    title: 'Elegía del hielo',
    short: 'Op. 2, Elegía del hielo',
    variable: 'Extensión del hielo marino',
    units: 'millones de km²',
    instrument: 'Armónicos de guitarra',
    wave: 'sine',
    baseMidi: 69,
    howItSounds: 'Menos hielo, notas más escasas y agudas. La tensión crece cuando el hielo cae por debajo de lo normal.',
    source: '[Título de la visualización del EIC]',
    cover: 'ice',
    ready: true,
    frames: mockFrames(29, -1, 'millones de km²'),
  },
  {
    id: 'veg',
    opus: 3,
    title: 'Pastoral',
    short: 'Op. 3, Pastoral',
    variable: 'Índice de vegetación',
    units: 'NDVI',
    instrument: 'Guitarra clásica',
    wave: 'sawtooth',
    baseMidi: 52,
    howItSounds: 'Más verde, notas más agudas y un ritmo más denso. La sequía se oye como tensión.',
    source: '[Título de la visualización del EIC]',
    cover: 'leaves',
    ready: true,
    frames: mockFrames(47, 0.6, 'NDVI'),
  },
  {
    id: 'co2',
    opus: 4,
    title: 'Respiración',
    short: 'Op. 4, Respiración',
    variable: 'Dióxido de carbono atmosférico',
    units: 'ppm',
    instrument: 'Órgano',
    wave: 'square',
    baseMidi: 48,
    howItSounds: 'Más CO₂, notas más graves y sostenidas.',
    source: '[Pendiente]',
    cover: 'air',
    ready: false,
    frames: mockFrames(61, 1, 'ppm'),
  },
  {
    id: 'cur',
    opus: 5,
    title: 'Corrientes',
    short: 'Op. 5, Corrientes',
    variable: 'Corrientes oceánicas',
    units: 'm/s',
    instrument: 'Violonchelo',
    wave: 'sawtooth',
    baseMidi: 45,
    howItSounds: 'Corrientes más rápidas, ritmo más rápido.',
    source: '[Pendiente]',
    cover: 'currents',
    ready: false,
    frames: mockFrames(83, 0.5, 'm/s'),
  },
];

export function tensionWord(t: number) {
  if (t < 0.33) return 'baja';
  if (t < 0.66) return 'media';
  return 'alta';
}
