import { useEffect, useState } from 'react';

export type TextSize = 'm' | 'l' | 'xl';

export interface Settings {
  announce: boolean; // anunciar cambios al lector de pantalla
  richText: boolean; // descripción enriquecida en pantalla
  legendFirst: boolean; // leyenda sonora antes del primer disco
  subtitles: boolean; // globo de texto de Tlalli
  textSize: TextSize;
  highContrast: boolean;
  reduceMotion: boolean;
  haptics: boolean; // vibración en valores extremos (Android)
  listView: boolean; // vista de lista sin ilustraciones
}

const KEY = 'socotlalli:ajustes';

function systemReducedMotion() {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
}

const defaults = (): Settings => ({
  announce: true,
  richText: true,
  legendFirst: true,
  subtitles: true,
  textSize: 'm',
  highContrast: false,
  reduceMotion: systemReducedMotion(),
  haptics: false,
  listView: false,
});

function load(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...defaults(), ...(JSON.parse(raw) as Partial<Settings>) };
  } catch {
    // Sin almacenamiento disponible: se usan los valores por defecto.
  }
  return defaults();
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings>(load);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(settings));
    } catch {
      // Ventana privada o almacenamiento bloqueado: los ajustes duran solo esta visita.
    }
    const root = document.documentElement;
    root.dataset.text = settings.textSize;
    root.dataset.contrast = settings.highContrast ? 'high' : 'normal';
    root.dataset.motion = settings.reduceMotion ? 'reduce' : 'full';
  }, [settings]);

  const update = <K extends keyof Settings>(key: K, value: Settings[K]) =>
    setSettings((prev) => ({ ...prev, [key]: value }));

  return [settings, update] as const;
}
