import { useEffect, useState } from 'react';
import { IconA11y } from './Icons';

// Pasos de carga. En la versión real, cada paso avanza cuando termina de cargar
// (fotogramas con fetch, samples con Tone.loaded(), partituras del JSON).
const STEPS = ['Fotogramas del EIC', 'Instrumentos', 'Partituras'];

export function Loading({ onEnter, onA11y }: { onEnter: () => void; onA11y: () => void }) {
  const [done, setDone] = useState(0);

  useEffect(() => {
    if (done >= STEPS.length) return;
    const t = window.setTimeout(() => setDone((d) => d + 1), 700);
    return () => window.clearTimeout(t);
  }, [done]);

  const ready = done >= STEPS.length;

  return (
    <main className="loading wrap">
      <button type="button" className="btn btn-ghost btn-sm loading-a11y" onClick={onA11y}>
        <IconA11y /> Accesibilidad
      </button>

      <div className="loader-record spin" aria-hidden="true">
        <span className="loader-label">
          <span className="loader-earth" />
        </span>
      </div>

      <div className="loading-title">
        <h1>Socotlalli</h1>
        <p className="loading-sub">Un refugio para escuchar la Tierra</p>
        <p className="loading-etym">
          <span lang="es">soco</span>: refugio, lugar para resguardarse · <span lang="nah">tlalli</span>: tierra, en náhuatl
        </p>
      </div>

      <div className="loading-progress">
        <div
          className="bar"
          role="progressbar"
          aria-label="Preparando el refugio"
          aria-valuemin={0}
          aria-valuemax={STEPS.length}
          aria-valuenow={done}
        >
          <span style={{ width: `${(done / STEPS.length) * 100}%` }} />
        </div>
        <ul className="steps">
          {STEPS.map((s, i) => (
            <li key={s} data-state={i < done ? 'done' : i === done ? 'active' : 'wait'}>
              {s} · {i < done ? 'listo' : i === done ? 'cargando' : 'en espera'}
            </li>
          ))}
        </ul>
        <p className="status" aria-live="polite">
          {ready ? 'Todo listo.' : `Cargando ${STEPS[done].toLowerCase()}… paso ${done + 1} de ${STEPS.length}`}
        </p>
      </div>

      <div className="loading-enter">
        <button type="button" className="btn btn-primary btn-lg" disabled={!ready} onClick={onEnter}>
          Entrar al refugio
        </button>
        <p className="hint">Usa audífonos: el sonido viaja de un oído al otro, de oeste a este.</p>
      </div>

      <p className="loading-credit">Imágenes: NASA Earth Information Center · NASA Space Apps Challenge 2026 · Ensenada</p>
    </main>
  );
}
