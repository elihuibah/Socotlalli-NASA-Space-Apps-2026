import type { KeyboardEvent } from 'react';
import type { Disc } from '../data/discs';
import { YEARS } from '../data/discs';
import { IconNext, IconPause, IconPlay, IconPrev } from './Icons';

interface Option<T extends string> {
  value: T;
  label: string;
}

/** Grupo de opciones excluyentes (radio) con navegación por flechas. */
export function Segmented<T extends string>(props: {
  label: string;
  value: T;
  options: Option<T>[];
  onChange: (v: T) => void;
  disabled?: boolean;
  size?: 'sm';
}) {
  const { label, value, options, onChange, disabled, size } = props;
  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    e.stopPropagation();
    const i = options.findIndex((o) => o.value === value);
    const n = (i + (e.key === 'ArrowRight' ? 1 : -1) + options.length) % options.length;
    onChange(options[n].value);
    const buttons = e.currentTarget.querySelectorAll<HTMLButtonElement>('button');
    buttons[n]?.focus();
  };
  return (
    <div role="radiogroup" aria-label={label} className={`segmented${size === 'sm' ? ' segmented--sm' : ''}`} onKeyDown={onKeyDown}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={o.value === value}
          tabIndex={o.value === value ? 0 : -1}
          disabled={disabled}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Transport(props: {
  playing: boolean;
  disabled: boolean;
  onToggle: () => void;
  onPrev: () => void;
  onNext: () => void;
}) {
  const { playing, disabled, onToggle, onPrev, onNext } = props;
  return (
    <div className="transport">
      <button type="button" className="icon-btn" onClick={onPrev} disabled={disabled} aria-label="Fotograma anterior">
        <IconPrev />
      </button>
      <button type="button" className="icon-btn icon-btn--main" onClick={onToggle} disabled={disabled} aria-label={playing ? 'Pausar' : 'Reproducir'}>
        {playing ? <IconPause /> : <IconPlay />}
      </button>
      <button type="button" className="icon-btn" onClick={onNext} disabled={disabled} aria-label="Fotograma siguiente">
        <IconNext />
      </button>
    </div>
  );
}

export function YearSelect(props: { id: string; year: number; onChange: (y: number) => void; disabled?: boolean }) {
  return (
    <label className="field" htmlFor={props.id}>
      <span>Año</span>
      <select id={props.id} value={props.year} disabled={props.disabled} onChange={(e) => props.onChange(Number(e.target.value))}>
        {YEARS.map((y, i) => (
          <option key={y} value={i}>
            {y}
          </option>
        ))}
      </select>
    </label>
  );
}

/** Portada de un disco dibujada con CSS. En real: el fotograma del EIC de esa visualización. */
export function Cover({ disc, large }: { disc: Disc; large?: boolean }) {
  return (
    <span className={`cover cover--${disc.cover}${large ? ' cover--lg' : ''}${disc.ready ? '' : ' is-soon'}`} aria-hidden="true">
      <span className="cover-op">Op. {disc.opus}</span>
      <span className="cover-title">{disc.title}</span>
      {!disc.ready && <span className="cover-soon">Próximamente</span>}
    </span>
  );
}
