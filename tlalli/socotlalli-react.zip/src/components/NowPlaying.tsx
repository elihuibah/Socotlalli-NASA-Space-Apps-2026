import type { Period } from '../App';
import type { Disc } from '../data/discs';
import { Segmented, Transport, YearSelect } from './Controls';

export function NowPlaying(props: {
  disc: Disc | null;
  frame: number;
  playing: boolean;
  period: Period;
  year: number;
  richText: boolean;
  setPeriod: (p: Period) => void;
  setYear: (y: number) => void;
  onToggle: () => void;
  onPrev: () => void;
  onNext: () => void;
  onDescribe: () => void;
  onOpenPlayer: () => void;
}) {
  const { disc, frame, playing, period, year, richText } = props;
  const f = disc ? disc.frames[frame] : null;

  return (
    <section className="now" id="controles" aria-label="Ahora reproduciendo">
      <div className="now-inner wrap">
        <div className="now-title">
          <p className="eyebrow">Ahora reproduciendo</p>
          {disc ? (
            <>
              <p className="now-name">
                Op. {disc.opus} · {disc.title}
              </p>
              <p className="now-sub">
                {disc.variable} · {disc.instrument}
              </p>
            </>
          ) : (
            <p className="now-name now-empty">Ningún disco en el tocadiscos</p>
          )}
        </div>

        <div className="now-controls">
          <div className="now-row">
            <Segmented<Period>
              label="Periodo"
              value={period}
              disabled={!disc}
              onChange={props.setPeriod}
              options={[
                { value: 'year', label: 'Un año' },
                { value: 'sequence', label: 'Todo el periodo' },
              ]}
            />
            {period === 'year' && <YearSelect id="year-now" year={year} onChange={props.setYear} disabled={!disc} />}
          </div>
          <div className="now-row">
            <Transport playing={playing} disabled={!disc} onToggle={props.onToggle} onPrev={props.onPrev} onNext={props.onNext} />
            {disc && (
              <span className="counter">
                {frame + 1} de {disc.frames.length}
              </span>
            )}
          </div>
        </div>

        <div className="now-desc">
          {disc && f ? (
            <>
              <p className="desc">
                <strong>{f.label}.</strong> {richText ? f.text : null}
              </p>
              <div className="now-row">
                <button type="button" className="link-btn" onClick={props.onDescribe}>
                  Describir más (D)
                </button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={props.onOpenPlayer}>
                  Ver tocadiscos
                </button>
              </div>
            </>
          ) : (
            <p className="desc muted">Elige un disco del estante para empezar.</p>
          )}
        </div>
      </div>
    </section>
  );
}
