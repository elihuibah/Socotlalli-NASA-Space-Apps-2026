const base = {
  width: 20,
  height: 20,
  viewBox: '0 0 24 24',
  'aria-hidden': true,
  focusable: false,
} as const;

export const IconPlay = () => (
  <svg {...base} fill="currentColor">
    <path d="M8 5v14l11-7z" />
  </svg>
);
export const IconPause = () => (
  <svg {...base} fill="currentColor">
    <path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" />
  </svg>
);
export const IconPrev = () => (
  <svg {...base} fill="currentColor">
    <path d="M6 6h2v12H6zM20 6v12L9.5 12z" />
  </svg>
);
export const IconNext = () => (
  <svg {...base} fill="currentColor">
    <path d="M16 6h2v12h-2zM4 6v12l10.5-6z" />
  </svg>
);
export const IconClose = () => (
  <svg {...base} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
export const IconBack = () => (
  <svg {...base} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M15 5l-7 7 7 7" />
  </svg>
);
export const IconA11y = () => (
  <svg {...base} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round">
    <circle cx="12" cy="4.5" r="1.8" />
    <path d="M5 8.5l7 1.5 7-1.5M12 10v4.5M12 14.5l-3 6M12 14.5l3 6" />
  </svg>
);
export const IconEar = () => (
  <svg {...base} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-5 2" />
    <path d="M10 10a2 2 0 0 1 4 0" />
  </svg>
);
export const IconList = () => (
  <svg {...base} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round">
    <path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01" />
  </svg>
);
