import type { KeyboardEvent } from 'react';
import type { Disc } from '../data/discs';
import { Cover } from './Controls';

interface Props {
  discs: Disc[];
  currentId: string | null;
  listView: boolean;
  onOpen: (disc: Disc, opener: HTMLElement) => void;
  registerCover: (id: string, el: HTMLButtonElement | null) => void;
}

const PER_SHELF = 3;

/** Flechas recorren los discos; Enter o Espacio abren el acercamiento. */
function roveFocus(e: KeyboardEvent<HTMLElement>) {
  const keys = ['ArrowRight', 'ArrowLeft', 'ArrowDown', 'ArrowUp', 'Home', 'End'];
  if (!keys.includes(e.key)) return;
  const buttons = Array.from(e.currentTarget.querySelectorAll<HTMLButtonElement>('button[data-disc]'));
  const i = buttons.indexOf(document.activeElement as HTMLButtonElement);
  if (i < 0) return;
  e.preventDefault();
  e.stopPropagation();
  let n = i;
  if (e.key === 'Home') n = 0;
  else if (e.key === 'End') n = buttons.length - 1;
  else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') n = (i + 1) % buttons.length;
  else n = (i - 1 + buttons.length) % buttons.length;
  buttons[n].focus();
}

function label(d: Disc, playing: boolean) {
  return `Op. ${d.opus}, ${d.title}: ${d.variable}${d.ready ? '' : ', próximamente'}${playing ? ', sonando ahora' : ''}`;
}

export function Shelf({ discs, currentId, listView, onOpen, registerCover }: Props) {
  if (listView) {
    return (
      <div className="disc-list-wrap" onKeyDown={roveFocus}>
        <h2 className="section-title">Discos</h2>
        <ul className="disc-list">
          {discs.map((d) => (
            <li key={d.id}>
              <button
                type="button"
                data-disc
                ref={(el) => {
                  registerCover(d.id, el);
                }}
                className={`disc-row${d.id === currentId ? ' is-playing' : ''}`}
                onClick={(e) => onOpen(d, e.currentTarget)}
              >
                <span className="disc-row-op">Op. {d.opus}</span>
                <span className="disc-row-main">
                  <span className="disc-row-title">{d.title}</span>
                  <span className="disc-row-meta">
                    {d.variable} · {d.instrument}
                    {d.ready ? '' : ' · Próximamente'}
                  </span>
                </span>
                {d.id === currentId && <span className="chip">Sonando</span>}
              </button>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  const shelves: Disc[][] = [];
  for (let i = 0; i < discs.length; i += PER_SHELF) shelves.push(discs.slice(i, i + PER_SHELF));

  return (
    <div className="shelf" role="group" aria-label="Estante de vinilos" onKeyDown={roveFocus}>
      {shelves.map((row, r) => (
        <div className="shelf-row" key={r}>
          {row.map((d) => {
            const playing = d.id === currentId;
            return (
              <button
                key={d.id}
                type="button"
                data-disc
                ref={(el) => {
                  registerCover(d.id, el);
                }}
                className={`cover-btn${playing ? ' is-playing' : ''}`}
                aria-label={label(d, playing)}
                onClick={(e) => onOpen(d, e.currentTarget)}
              >
                <Cover disc={d} />
                {playing && (
                  <span className="badge-now" aria-hidden="true">
                    Sonando
                  </span>
                )}
              </button>
            );
          })}
        </div>
      ))}
      <p className="shelf-hint">← → recorrer el estante · Enter elegir</p>
    </div>
  );
}
