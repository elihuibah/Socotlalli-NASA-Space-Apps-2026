import { useEffect, useRef } from 'react';
import type { Settings, TextSize } from '../hooks/useSettings';
import { Segmented } from './Controls';
import { IconClose } from './Icons';

type Update = <K extends keyof Settings>(key: K, value: Settings[K]) => void;

const canVibrate = typeof navigator !== 'undefined' && 'vibrate' in navigator;

function Toggle({ id, label, checked, onChange }: { id: string; label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="toggle" htmlFor={id}>
      <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  );
}

export function A11yPanel({ open, onClose, settings, update }: { open: boolean; onClose: () => void; settings: Settings; update: Update }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      className="dialog drawer"
      aria-labelledby="a11y-title"
      onClose={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="drawer-body">
        <div className="drawer-head">
          <h2 id="a11y-title" className="dialog-title">
            Accesibilidad
          </h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Cerrar accesibilidad">
            <IconClose />
          </button>
        </div>

        <fieldset>
          <legend>Escuchar</legend>
          <Toggle id="a-announce" label="Anunciar cambios al lector de pantalla" checked={settings.announce} onChange={(v) => update('announce', v)} />
          <Toggle id="a-rich" label="Descripción enriquecida en pantalla" checked={settings.richText} onChange={(v) => update('richText', v)} />
          <Toggle id="a-legend" label="Leyenda sonora antes del primer disco" checked={settings.legendFirst} onChange={(v) => update('legendFirst', v)} />
          <Toggle id="a-subs" label="Subtítulos de lo que dice Tlalli" checked={settings.subtitles} onChange={(v) => update('subtitles', v)} />
        </fieldset>

        <fieldset>
          <legend>Ver</legend>
          <div className="toggle">
            <span id="a-size-label">Tamaño de texto</span>
            <Segmented<TextSize>
              label="Tamaño de texto"
              size="sm"
              value={settings.textSize}
              onChange={(v) => update('textSize', v)}
              options={[
                { value: 'm', label: 'A' },
                { value: 'l', label: 'A+' },
                { value: 'xl', label: 'A++' },
              ]}
            />
          </div>
          <Toggle id="a-contrast" label="Alto contraste" checked={settings.highContrast} onChange={(v) => update('highContrast', v)} />
          <Toggle id="a-motion" label="Reducir movimiento" checked={settings.reduceMotion} onChange={(v) => update('reduceMotion', v)} />
        </fieldset>

        <fieldset>
          <legend>Sentir y navegar</legend>
          {canVibrate && (
            <Toggle id="a-haptics" label="Vibrar en valores extremos" checked={settings.haptics} onChange={(v) => update('haptics', v)} />
          )}
          <Toggle id="a-list" label="Vista de lista, sin ilustraciones" checked={settings.listView} onChange={(v) => update('listView', v)} />
        </fieldset>

        <div className="shortcuts">
          <p className="legend-like">Atajos de teclado</p>
          <dl>
            <dt><kbd>Espacio</kbd></dt>
            <dd>Reproducir o pausar</dd>
            <dt><kbd>←</kbd> <kbd>→</kbd></dt>
            <dd>Fotograma anterior o siguiente</dd>
            <dt><kbd>1</kbd>–<kbd>5</kbd></dt>
            <dd>Elegir disco</dd>
            <dt><kbd>D</kbd></dt>
            <dd>Describir lo que suena</dd>
            <dt><kbd>L</kbd></dt>
            <dd>Leyenda sonora</dd>
            <dt><kbd>Esc</kbd></dt>
            <dd>Cerrar</dd>
          </dl>
        </div>
      </div>
    </dialog>
  );
}
