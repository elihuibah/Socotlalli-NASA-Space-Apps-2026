import { useEffect, useState } from 'react';
import type { MouseEvent } from 'react';
import type { Period } from '../App';
import type { ListenMode } from '../audio/engine';
import { engine } from '../audio/engine';
import type { Disc, Region } from '../data/discs';
import { FRAME_MS, GRID, REGIONS, tensionWord } from '../data/discs';
import { Segmented, Transport, YearSelect } from './Controls';
import { IconA11y, IconBack, IconEar } from './Icons';

interface Props {
  disc: Disc;
  frame: number;
  playing: boolean;
  period: Period;
  year: number;
  mode: ListenMode;
  region: Region;
  richText: boolean;
  setPeriod: (p: Period) => void;
  setYear: (y: number) => void;
  setMode: (m: ListenMode) => void;
  setRegion: (id: string) => void;
  onBack: () => void;
  onToggle: () => void;
  onPrev: () => void;
  onNext: () => void;
  onDescribe: () => void;
  onLegend: () => void;
  onA11y: () => void;
}

const MAX_NOTES = 24;

export function Player(p: Props) {
  const { disc, frame, playing, mode, region } = p;
  const f = disc.frames[frame];
  const progress = frame / (disc.frames.length - 1);
  const [notes, setNotes] = useState<{ id: number; midi: number; tension: number }[]>([]);

  // Tira de notas: se alimenta del evento onNote del motor de audio.
  useEffect(() => {
    let id = 0;
    return engine.onNote((n) => {
      id += 1;
      const note = { id, midi: n.midi, tension: n.tension };
      setNotes((prev) => [...prev.slice(-(MAX_NOTES - 1)), note]);
    });
  }, []);

  const pickRegion = (e: MouseEvent<HTMLDivElement>) => {
    const box = e.currentTarget.getBoundingClientRect();
    const col = ((e.clientX - box.left) / box.width) * GRID.cols;
    const row = ((e.clientY - box.top) / box.height) * GRID.rows;
    let best = REGIONS[0];
    let bestD = Infinity;
    for (const r of REGIONS) {
      if (r.id === 'global') continue;
      const d = Math.hypot(r.col + r.w / 2 - col, r.row + r.h / 2 - row);
      if (d < bestD) {
        bestD = d;
        best = r;
      }
    }
    p.setRegion(best.id);
    p.setMode('region');
  };

  const tension = Math.abs(f.anomaly);
  const tempo = Math.round(60 + 60 * f.change);

  return (
    <div className="player">
      <header className="topbar wrap">
        <button type="button" className="btn btn-ghost btn-sm" onClick={p.onBack}>
          <IconBack /> <span>Volver a la sala</span>
        </button>
        <p className="player-title">
          Op. {disc.opus} · {disc.title}
        </p>
        <nav aria-label="Opciones" className="topnav">
          <button type="button" className="btn btn-ghost btn-sm" onClick={p.onLegend}>
            <IconEar /> <span className="lbl">Cómo se escucha</span>
          </button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={p.onA11y}>
            <IconA11y /> <span className="lbl">Accesibilidad</span>
          </button>
        </nav>
      </header>

      <main className="player-main wrap" id="contenido">
        <section className="deck" aria-label="Tocadiscos visto desde arriba">
          <div className="deck-plinth" aria-hidden="true">
            <span className="deck-platter">
              <span className={`deck-record${playing ? ' spin' : ''}`}>
                <span className={`deck-label label--${disc.cover}`}>
                  <span>{f.label}</span>
                </span>
              </span>
            </span>
            <span className="deck-pivot" />
            <span className="deck-arm" style={{ transform: `rotate(${14 + progress * 24}deg)` }} />
          </div>
          <p className="deck-caption">
            Fotograma {frame + 1} de {disc.frames.length} · el brazo avanza con el tiempo
          </p>
        </section>

        <section className="frame" aria-label="Fotograma del EIC">
          <div
            className="map"
            role="img"
            aria-label={`Fotograma de ${disc.variable.toLowerCase()}, ${f.label}. Haz clic en el mapa para elegir una zona, o usa el selector Zona.`}
            onClick={pickRegion}
          >
            {/* Aquí va el fotograma real: <img src={f.image} alt="" /> */}
            <span className="map-ph" aria-hidden="true">
              Fotograma del EIC · mapa global 2:1
              <small>{f.label}</small>
            </span>
            {mode === 'scan' && (
              <span
                key={`${disc.id}-${frame}`}
                className={`scan${playing ? '' : ' is-paused'}`}
                style={{ animationDuration: `${FRAME_MS}ms` }}
                aria-hidden="true"
              >
                <span>Barrido</span>
              </span>
            )}
            {region.id !== 'global' && (
              <span
                className={`region${mode === 'region' ? ' is-active' : ''}`}
                aria-hidden="true"
                style={{
                  left: `${(region.col / GRID.cols) * 100}%`,
                  top: `${(region.row / GRID.rows) * 100}%`,
                  width: `${(region.w / GRID.cols) * 100}%`,
                  height: `${(region.h / GRID.rows) * 100}%`,
                }}
              >
                <span>{region.name}</span>
              </span>
            )}
          </div>
          <div className="colorbar">
            <span>[MÍN] {disc.units}</span>
            <span className={`colorbar-ramp ramp--${disc.cover}`} aria-hidden="true" />
            <span>[MÁX] {disc.units}</span>
            <span className="muted">Barra de color de la visualización</span>
          </div>
        </section>

        <section className="panel controls" aria-label="Controles">
          <div className="now-row">
            <Segmented<ListenMode>
              label="Modo de escucha"
              value={mode}
              onChange={p.setMode}
              options={[
                { value: 'scan', label: 'Barrido' },
                { value: 'region', label: 'Lugar en el tiempo' },
              ]}
            />
            <Segmented<Period>
              label="Periodo"
              value={p.period}
              onChange={p.setPeriod}
              options={[
                { value: 'year', label: 'Un año' },
                { value: 'sequence', label: 'Todo el periodo' },
              ]}
            />
          </div>
          <div className="now-row">
            <Transport playing={playing} disabled={false} onToggle={p.onToggle} onPrev={p.onPrev} onNext={p.onNext} />
            {p.period === 'year' && <YearSelect id="year-player" year={p.year} onChange={p.setYear} />}
            <label className="field" htmlFor="region">
              <span>Zona</span>
              <select id="region" value={region.id} onChange={(e) => p.setRegion(e.target.value)}>
                {REGIONS.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <div className="score" role="img" aria-label="Tira de notas: lo que suena ahora">
            {[0, 1, 2, 3, 4].map((i) => (
              <span key={i} className="staff" style={{ top: `${18 + i * 16}%` }} aria-hidden="true" />
            ))}
            {notes.map((n, i) => (
              <span
                key={n.id}
                className={`note${n.tension > 0.66 ? ' is-tense' : ''}`}
                aria-hidden="true"
                style={{
                  left: `${4 + (i / MAX_NOTES) * 92}%`,
                  bottom: `${Math.max(6, Math.min(88, ((n.midi - 45) / 40) * 100))}%`,
                }}
              />
            ))}
          </div>
        </section>

        <section className="panel layers" aria-label="Capas">
          <p className="eyebrow">Capas · datos de ejemplo</p>
          <label className="meter-row">
            <span>Melodía · {disc.instrument.toLowerCase()}</span>
            <meter min={0} max={1} value={f.value} />
          </label>
          <label className="meter-row">
            <span>Tensión armónica · {tensionWord(tension)}</span>
            <meter min={0} max={1} low={0.33} high={0.66} optimum={0} value={tension} />
          </label>
          <label className="meter-row">
            <span>Densidad rítmica</span>
            <meter min={0} max={1} value={f.variation} />
          </label>
          <p className="meter-row">
            <span>Tempo</span>
            <span className="num">{tempo} ppm</span>
          </p>
        </section>

        <section className="panel describe" aria-label="Descripción">
          <p className="eyebrow">Descripción</p>
          <p className="desc">
            <strong>{f.label}.</strong> {p.richText ? f.text : null} Tensión {tensionWord(tension)}
            {mode === 'region' ? `, escuchando ${region.name.toLowerCase()}.` : ', barrido de oeste a este.'}
          </p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={p.onDescribe}>
            Describir ahora (D)
          </button>
        </section>
      </main>
    </div>
  );
}
