import { useEffect, useRef } from 'react';
import { engine } from '../audio/engine';
import { IconClose, IconPlay } from './Icons';

const RULES = [
  { title: 'Valor más alto, nota más aguda.', sub: 'Un mar más cálido suena más agudo.' },
  { title: 'Lejos de lo normal, más tensión.', sub: 'Cerca de lo normal suenan acordes limpios; lejos, disonancias.' },
  { title: 'Más variación, más notas.', sub: 'Las zonas irregulares tocan ritmos más rápidos.' },
  { title: 'Cambio rápido, tempo rápido.', sub: 'Si el mapa cambia mucho entre fotogramas, la música acelera.' },
  { title: 'Izquierda y derecha son oeste y este.', sub: 'Con audífonos, el barrido cruza de un oído al otro.' },
];

export function Legend({ open, onClose }: { open: boolean; onClose: () => void }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  return (
    <dialog ref={ref} className="dialog legend" aria-labelledby="legend-title" onClose={onClose}>
      <div className="legend-body">
        <button type="button" className="icon-btn dialog-close" onClick={onClose} aria-label="Cerrar la leyenda">
          <IconClose />
        </button>
        <h2 id="legend-title" className="dialog-title">
          Cómo se escucha
        </h2>
        <p className="muted">Cinco reglas, una a la vez. Escucha cada ejemplo antes del primer disco.</p>
        <ol className="rules">
          {RULES.map((r, i) => (
            <li key={r.title}>
              <span className="rule-n" aria-hidden="true">
                {i + 1}
              </span>
              <span className="rule-text">
                <strong>{r.title}</strong>
                <span>{r.sub}</span>
              </span>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => engine.preview(i)} aria-label={`Escuchar ejemplo de la regla ${i + 1}`}>
                <IconPlay /> <span className="lbl">Escuchar ejemplo</span>
              </button>
            </li>
          ))}
        </ol>
        <p>
          Cada disco tiene su instrumento: el mar, piano; el hielo, armónicos de guitarra; la vegetación, guitarra clásica. Los
          valores extremos entran con guitarra eléctrica.
        </p>
        <div className="actions">
          <button type="button" className="btn btn-primary" onClick={onClose}>
            Empezar a escuchar
          </button>
        </div>
      </div>
    </dialog>
  );
}
