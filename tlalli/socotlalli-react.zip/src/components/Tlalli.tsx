// Espacio reservado para la ilustración 2D de Tlalli.
// Al tener el arte, reemplacen .tlalli-ph por <img src="/art/tlalli.svg" alt="..."> o las capas SVG.
export function Tlalli({ message, showBubble }: { message: string; showBubble: boolean }) {
  return (
    <aside className="tlalli" aria-label="Tlalli">
      {showBubble && (
        <p className="bubble">
          <span className="bubble-name">Tlalli</span>
          {message}
        </p>
      )}
      <div className="tlalli-ph" role="img" aria-label="Ilustración de Tlalli, la Tierra personificada, sentada en un sillón">
        <span className="tlalli-planet" aria-hidden="true" />
        <span className="tlalli-body" aria-hidden="true" />
        <span className="tlalli-chair" aria-hidden="true" />
        <span className="ph-label" aria-hidden="true">
          Ilustración 2D de Tlalli · espacio reservado
        </span>
      </div>
    </aside>
  );
}
