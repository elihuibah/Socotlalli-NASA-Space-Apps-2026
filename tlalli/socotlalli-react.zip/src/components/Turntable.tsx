import type { RefObject } from 'react';
import type { Disc } from '../data/discs';

export function Turntable(props: {
  disc: Disc | null;
  playing: boolean;
  platterRef: RefObject<HTMLSpanElement>;
  onOpen: () => void;
}) {
  const { disc, playing, platterRef, onOpen } = props;
  return (
    <button
      type="button"
      className="turntable"
      onClick={onOpen}
      aria-label={disc ? `Tocadiscos con ${disc.title}. Abrir la vista de reproducción` : 'Tocadiscos vacío. Elige primero un disco del estante'}
    >
      <span className="tt-base" aria-hidden="true">
        <span className="tt-platter" ref={platterRef}>
          {disc && (
            <span className={`tt-record${playing ? ' spin' : ''}`}>
              <span className={`tt-label label--${disc.cover}`} />
            </span>
          )}
        </span>
        <span className={`tt-arm${disc ? ' is-down' : ''}`} />
        <span className="tt-knob" />
      </span>
      <span className="tt-caption">{disc ? 'Ver reproducción' : 'Tocadiscos'}</span>
    </button>
  );
}
