import { IconA11y, IconEar, IconList } from './Icons';

export function Header(props: { listView: boolean; onLegend: () => void; onList: () => void; onA11y: () => void }) {
  return (
    <header className="topbar wrap">
      <p className="brand">
        <span className="brand-name">Socotlalli</span>
        <span className="brand-sub">el refugio</span>
      </p>
      <nav aria-label="Opciones" className="topnav">
        <button type="button" className="btn btn-ghost btn-sm" onClick={props.onLegend}>
          <IconEar /> <span className="lbl">Cómo se escucha</span>
        </button>
        <button type="button" className="btn btn-ghost btn-sm" aria-pressed={props.listView} onClick={props.onList}>
          <IconList /> <span className="lbl">Vista de lista</span>
        </button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={props.onA11y}>
          <IconA11y /> <span className="lbl">Accesibilidad</span>
        </button>
      </nav>
    </header>
  );
}
