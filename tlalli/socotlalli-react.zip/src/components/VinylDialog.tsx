import { useEffect, useRef } from 'react';
import type { Disc } from '../data/discs';
import { YEARS } from '../data/discs';
import { Cover } from './Controls';
import { IconClose, IconPlay } from './Icons';

export function VinylDialog(props: {
  disc: Disc | null;
  onClose: () => void;
  onPlace: (d: Disc) => void;
  onSample: (d: Disc) => void;
}) {
  const { disc, onClose, onPlace, onSample } = props;
  const ref = useRef<HTMLDialogElement>(null);

  // <dialog> nativo: atrapa el foco, Esc lo cierra y vuelve inerte el resto de la página.
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (disc && !d.open) d.showModal();
    if (!disc && d.open) d.close();
  }, [disc]);

  return (
    <dialog
      ref={ref}
      className="dialog vinyl-dialog"
      aria-labelledby="vinyl-title"
      onClose={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {disc && (
        <div className="vinyl-body">
          <div className="vinyl-art">
            <span className={`vinyl-record label-host label--${disc.cover}`} aria-hidden="true" />
            <Cover disc={disc} large />
          </div>
          <div className="vinyl-info">
            <button type="button" className="icon-btn dialog-close" onClick={onClose} aria-label="Cerrar y volver al estante">
              <IconClose />
            </button>
            <p className="eyebrow">
              Op. {disc.opus} · {disc.variable}
            </p>
            <h2 id="vinyl-title" className="vinyl-title">
              {disc.title}
            </h2>
            <dl className="facts">
              <dt>Visualización</dt>
              <dd>{disc.source}</dd>
              <dt>Periodo</dt>
              <dd>
                {YEARS[0]}–{YEARS[YEARS.length - 1]} · {disc.frames.length} fotogramas
              </dd>
              <dt>Unidades</dt>
              <dd>{disc.units}</dd>
              <dt>Instrumento</dt>
              <dd>{disc.instrument}</dd>
            </dl>
            <div className="how">
              <p className="eyebrow">Cómo suena</p>
              <p>{disc.howItSounds}</p>
            </div>
            {disc.ready ? (
              <div className="actions">
                <button type="button" className="btn btn-primary" onClick={() => onPlace(disc)} autoFocus>
                  Colocar en el tocadiscos
                </button>
                <button type="button" className="btn btn-ghost" onClick={() => onSample(disc)}>
                  <IconPlay /> Escuchar 10 segundos
                </button>
              </div>
            ) : (
              <p className="note">Este disco todavía no tiene datos. Llegará si da tiempo.</p>
            )}
            <p className="hint">Esc cierra</p>
          </div>
        </div>
      )}
    </dialog>
  );
}
