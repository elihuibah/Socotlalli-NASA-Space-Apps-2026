import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { engine } from './audio/engine';
import type { ListenMode } from './audio/engine';
import { DISCS, FRAME_MS, FRAMES_PER_YEAR, REGIONS, tensionWord } from './data/discs';
import type { Disc, Frame } from './data/discs';
import { useSettings } from './hooks/useSettings';
import { A11yPanel } from './components/A11yPanel';
import { Header } from './components/Header';
import { Legend } from './components/Legend';
import { Loading } from './components/Loading';
import { NowPlaying } from './components/NowPlaying';
import { Player } from './components/Player';
import { Shelf } from './components/Shelf';
import { Tlalli } from './components/Tlalli';
import { Turntable } from './components/Turntable';
import { VinylDialog } from './components/VinylDialog';

export type Period = 'year' | 'sequence';
type View = 'loading' | 'room' | 'player';
type Flight = { from: DOMRect; to: DOMRect; disc: Disc };

const WELCOME = 'Hola, soy Tlalli. Este es mi refugio. Elige un disco del estante y escucha cómo he cambiado.';

function describe(d: Disc, f: Frame) {
  return `${d.title}, ${f.label}. ${f.text} Tensión ${tensionWord(Math.abs(f.anomaly))}.`;
}

export default function App() {
  const [settings, setSetting] = useSettings();
  const [view, setView] = useState<View>('loading');
  const [selected, setSelected] = useState<Disc | null>(null);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [frame, setFrame] = useState(0);
  const [period, setPeriodState] = useState<Period>('sequence');
  const [year, setYearState] = useState(0);
  const [mode, setMode] = useState<ListenMode>('scan');
  const [regionId, setRegionId] = useState(REGIONS[0].id);
  const [legendOpen, setLegendOpen] = useState(false);
  const [a11yOpen, setA11yOpen] = useState(false);
  const [announcement, setAnnouncement] = useState('');
  const [flight, setFlight] = useState<Flight | null>(null);
  const [tlalliSays, setTlalliSays] = useState(WELCOME);

  const coverRefs = useRef(new Map<string, HTMLButtonElement>());
  const platterRef = useRef<HTMLSpanElement>(null);
  const openerRef = useRef<HTMLElement | null>(null);
  const flyRef = useRef<HTMLDivElement>(null);
  const legendShown = useRef(false);

  const current = useMemo(() => DISCS.find((d) => d.id === currentId) ?? null, [currentId]);
  const region = REGIONS.find((r) => r.id === regionId) ?? REGIONS[0];
  const f = current ? current.frames[frame] : null;

  // ---- Avance de fotogramas ------------------------------------------------
  const bounds = useCallback((): [number, number] => {
    if (!current) return [0, 0];
    if (period === 'year') return [year * FRAMES_PER_YEAR, year * FRAMES_PER_YEAR + FRAMES_PER_YEAR - 1];
    return [0, current.frames.length - 1];
  }, [current, period, year]);

  const step = useCallback(
    (dir: 1 | -1) => {
      const [a, b] = bounds();
      setFrame((i) => {
        const n = i + dir;
        if (n > b) return a;
        if (n < a) return b;
        return n;
      });
    },
    [bounds],
  );

  const setPeriod = (p: Period) => {
    setPeriodState(p);
    if (p === 'year') setFrame(year * FRAMES_PER_YEAR);
  };
  const setYear = (y: number) => {
    setYearState(y);
    setFrame(y * FRAMES_PER_YEAR);
  };

  useEffect(() => {
    if (!playing) return;
    const t = window.setInterval(() => step(1), FRAME_MS);
    return () => window.clearInterval(t);
  }, [playing, step]);

  // ---- Sincronía con el motor de audio --------------------------------------
  useEffect(() => engine.setFrame(frame), [frame]);
  useEffect(() => engine.setMode(mode), [mode]);
  useEffect(() => engine.setRegion(region.col + region.w / 2, region.row + region.h / 2), [region]);

  // ---- Anuncios para lector de pantalla y vibración -------------------------
  useEffect(() => {
    if (!current || !f) return;
    if (settings.announce) setAnnouncement(`${current.short}. ${f.label}. ${settings.richText ? f.text : ''}`);
    if (settings.haptics && Math.abs(f.anomaly) > 0.75) {
      try {
        navigator.vibrate?.(150);
      } catch {
        // Dispositivo sin vibración.
      }
    }
  }, [current, f, settings.announce, settings.richText, settings.haptics]);

  const describeNow = useCallback(() => {
    // El espacio duro alterno obliga al lector de pantalla a repetir el mensaje.
    setAnnouncement((prev) => {
      const text = current && f ? describe(current, f) : 'No hay ningún disco sonando. Elige uno del estante.';
      return prev === text ? `${text} ` : text;
    });
  }, [current, f]);

  // ---- Flujo de los discos --------------------------------------------------
  const openDisc = useCallback((d: Disc, opener: HTMLElement | null) => {
    openerRef.current = opener;
    setSelected(d);
    setTlalliSays(d.ready ? `Ese disco guarda ${d.variable.toLowerCase()}. ¿Lo ponemos?` : `${d.title} todavía está en preparación.`);
  }, []);

  const closeDisc = () => {
    setSelected(null);
    openerRef.current?.focus();
  };

  const finishPlace = (d: Disc) => {
    setFlight(null);
    setCurrentId(d.id);
    setPeriodState('sequence');
    setFrame(0);
    engine.loadDisc(d);
    engine.play();
    setPlaying(true);
    setTlalliSays(`Escucha: ${d.title}. ${d.howItSounds}`);
    openerRef.current?.focus();
  };

  const place = (d: Disc) => {
    setSelected(null);
    const cover = coverRefs.current.get(d.id);
    const platter = platterRef.current;
    if (settings.reduceMotion || settings.listView || !cover || !platter) {
      finishPlace(d);
      return;
    }
    setFlight({ from: cover.getBoundingClientRect(), to: platter.getBoundingClientRect(), disc: d });
  };

  // Animación de inserción: el disco sale del estante y cae en el plato (900 ms).
  useLayoutEffect(() => {
    const el = flyRef.current;
    if (!flight || !el) return;
    const { from, to, disc } = flight;
    const dx = to.left + to.width / 2 - (from.left + from.width / 2);
    const dy = to.top + to.height / 2 - (from.top + from.height / 2);
    const scale = to.width / from.width;
    const anim = el.animate(
      [
        { transform: 'translate(0, 0) scale(1) rotate(0deg)' },
        { transform: `translate(${dx * 0.5}px, ${Math.min(dy, 0) * 0.5 - 90}px) scale(${(1 + scale) / 2}) rotate(180deg)`, offset: 0.55 },
        { transform: `translate(${dx}px, ${dy}px) scale(${scale}) rotate(360deg)` },
      ],
      { duration: 900, easing: 'cubic-bezier(.3,.7,.2,1)', fill: 'forwards' },
    );
    anim.onfinish = () => finishPlace(disc);
    return () => anim.cancel();
    // finishPlace depende solo de setters estables
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flight]);

  const togglePlay = useCallback(() => {
    if (!current) {
      setAnnouncement('Primero elige un disco del estante.');
      return;
    }
    if (playing) {
      engine.pause();
      setPlaying(false);
    } else {
      engine.play();
      setPlaying(true);
    }
  }, [current, playing]);

  const openPlayer = () => {
    if (current) setView('player');
    else {
      setTlalliSays('El tocadiscos está vacío. Primero elige un disco del estante.');
      setAnnouncement('El tocadiscos está vacío. Primero elige un disco del estante.');
    }
  };

  const enter = async () => {
    await engine.start(); // el navegador exige este clic para activar el audio
    setView('room');
    if (settings.legendFirst && !legendShown.current) {
      legendShown.current = true;
      setLegendOpen(true);
    }
  };

  // ---- Atajos de teclado -----------------------------------------------------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (view === 'loading' || e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target as HTMLElement | null;
      if (t?.closest('input, select, textarea, dialog[open], [role="radiogroup"], .shelf, .disc-list-wrap')) return;
      if (e.key === ' ' && (!t || t === document.body)) {
        e.preventDefault();
        togglePlay();
      } else if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && current) {
        e.preventDefault();
        step(e.key === 'ArrowRight' ? 1 : -1);
      } else if (/^[1-5]$/.test(e.key)) {
        const d = DISCS[Number(e.key) - 1];
        if (d) openDisc(d, coverRefs.current.get(d.id) ?? null);
      } else if (e.key === 'd' || e.key === 'D') {
        describeNow();
      } else if (e.key === 'l' || e.key === 'L') {
        setLegendOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [view, current, step, togglePlay, describeNow, openDisc]);

  const registerCover = useCallback((id: string, el: HTMLButtonElement | null) => {
    if (el) coverRefs.current.set(id, el);
    else coverRefs.current.delete(id);
  }, []);

  return (
    <div className="app" data-view={settings.listView ? 'list' : 'scene'}>
      {view !== 'loading' && (
        <a className="skip" href="#controles">
          Saltar a la reproducción
        </a>
      )}

      {view === 'loading' && <Loading onEnter={enter} onA11y={() => setA11yOpen(true)} />}

      {view === 'room' && (
        <>
          <Header
            listView={settings.listView}
            onLegend={() => setLegendOpen(true)}
            onList={() => setSetting('listView', !settings.listView)}
            onA11y={() => setA11yOpen(true)}
          />
          <main className="scene wrap" id="contenido">
            {!settings.listView && <Tlalli message={tlalliSays} showBubble={settings.subtitles} />}
            <section className="room" aria-label="La sala">
              {!settings.listView && (
                <div className="window" aria-hidden="true">
                  <span className="window-moon" />
                </div>
              )}
              <Shelf discs={DISCS} currentId={currentId} listView={settings.listView} onOpen={openDisc} registerCover={registerCover} />
              {!settings.listView && (
                <div className="table">
                  <Turntable disc={current} playing={playing} platterRef={platterRef} onOpen={openPlayer} />
                  <span className="table-top" aria-hidden="true" />
                </div>
              )}
              {settings.listView && current && (
                <button type="button" className="btn btn-ghost" onClick={openPlayer}>
                  Ver la reproducción detallada
                </button>
              )}
            </section>
          </main>
          <p className="footnote wrap">Prototipo con datos de ejemplo · Imágenes: NASA Earth Information Center</p>
          <NowPlaying
            disc={current}
            frame={frame}
            playing={playing}
            period={period}
            year={year}
            richText={settings.richText}
            setPeriod={setPeriod}
            setYear={setYear}
            onToggle={togglePlay}
            onPrev={() => step(-1)}
            onNext={() => step(1)}
            onDescribe={describeNow}
            onOpenPlayer={openPlayer}
          />
        </>
      )}

      {view === 'player' && current && (
        <Player
          disc={current}
          frame={frame}
          playing={playing}
          period={period}
          year={year}
          mode={mode}
          region={region}
          richText={settings.richText}
          setPeriod={setPeriod}
          setYear={setYear}
          setMode={setMode}
          setRegion={setRegionId}
          onBack={() => setView('room')}
          onToggle={togglePlay}
          onPrev={() => step(-1)}
          onNext={() => step(1)}
          onDescribe={describeNow}
          onLegend={() => setLegendOpen(true)}
          onA11y={() => setA11yOpen(true)}
        />
      )}

      <VinylDialog disc={selected} onClose={closeDisc} onPlace={place} onSample={(d) => engine.sample(d)} />
      <Legend open={legendOpen} onClose={() => setLegendOpen(false)} />
      <A11yPanel open={a11yOpen} onClose={() => setA11yOpen(false)} settings={settings} update={setSetting} />

      <div className="sr-only" aria-live="polite">
        {announcement}
      </div>

      {flight && (
        <div
          ref={flyRef}
          className={`flying-record label-host label--${flight.disc.cover}`}
          aria-hidden="true"
          style={{ left: flight.from.left, top: flight.from.top, width: flight.from.width, height: flight.from.height }}
        />
      )}
    </div>
  );
}
